---
name: Help needed
about: In case you're having an issue, we will try to help you
title: ''
labels: help wanted
assignees: extatent

---

**Describe the issue**
A clear and concise description of what the issue is.

**Screenshots**
If applicable, add screenshots to help explain your issue.

**Additional context**
Add any other context about the issue here.
